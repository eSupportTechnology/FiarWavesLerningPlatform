

<?php $__env->startSection('title', 'Customer Details'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Customer Profile</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.customers.index')); ?>">Customers</a></li>
    <li class="breadcrumb-item active"><?php echo e($customer->name); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Customer Info -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Customer Information</h5>
            <a href="<?php echo e(route('admin.customers.index')); ?>" class="btn btn-light btn-sm">← Back to List</a>
        </div>

        <div class="card-body">
            <table class="table table-bordered">
                <tr><th>Student ID</th><td><?php echo e($customer->stu_id ?? 'Not Assigned'); ?></td></tr>
                <tr><th>Name</th><td><?php echo e($customer->name); ?></td></tr>
                <tr><th>Email</th><td><?php echo e($customer->email); ?></td></tr>
                <tr><th>Contact Number</th><td><?php echo e($customer->contact_number); ?></td></tr>
                <tr><th>Status</th>
                    <td>
                        <span class="badge bg-<?php echo e($customer->status ? 'success' : 'secondary'); ?>">
                            <?php echo e($customer->status ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                </tr>
                <tr><th>Email Verified</th>
                    <td>
                        <?php if($customer->email_verified_at): ?>
                            <span class="text-success">Verified on <?php echo e($customer->email_verified_at->format('Y-m-d')); ?></span>
                        <?php else: ?>
                            <span class="text-danger">Not Verified</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr><th>Registered At</th><td><?php echo e($customer->created_at->format('Y-m-d H:i')); ?></td></tr>
            </table>
        </div>
    </div>

    <!-- Purchased Courses Section -->
    <div class="card">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0">Purchased Courses</h5>
        </div>
        <div class="card-body">
            <?php if($customer->bookings->count()): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered text-center">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Course Name</th>
                                <th>Duration</th>
                                <th>Mode</th>
                                <th>Payment</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $customer->bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($booking->course->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($booking->course->duration); ?> days</td>
                                    <td><?php echo e(ucfirst($booking->course->mode)); ?></td>
                                    <td><?php echo e(ucfirst($booking->payment_status)); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($booking->status === 'Confirmed' ? 'success' : ($booking->status === 'Pending' ? 'warning' : 'secondary')); ?>">
                                            <?php echo e($booking->status); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">No course bookings found for this student.</p>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/customers/show.blade.php ENDPATH**/ ?>