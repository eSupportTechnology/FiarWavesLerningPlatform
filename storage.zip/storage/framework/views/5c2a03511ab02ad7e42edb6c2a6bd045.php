

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h4 class="mb-3">Zoom Links for: <strong><?php echo e($booking->course->name); ?></strong></h4>

    <?php $__empty_1 = true; $__currentLoopData = $booking->course->zoomLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-body">
                <h6 class="mb-1"><?php echo e($link->week_name); ?></h6>
                <p class="mb-2 text-muted"><?php echo e($link->description); ?></p>
                <a href="<?php echo e($link->zoom_link); ?>" target="_blank" class="btn btn-sm btn-outline-info">
                    <i class="bi bi-link-45deg"></i> Join Zoom
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-muted">No Zoom links available for this course.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('StudentDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/StudentDashboard/course/zoom-links.blade.php ENDPATH**/ ?>