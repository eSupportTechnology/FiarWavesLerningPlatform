
<?php $__env->startSection('title', 'Create New Course'); ?>

<?php $__env->startSection('css'); ?>
<!-- Include Quill CSS -->
<link rel="stylesheet" type="text/css" href="../assets/css/vendors/quill.snow.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    #editor8 {
        height: 300px;
        background-color: white;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Create New Course</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Course Management</li>
    <li class="breadcrumb-item active">Create New Course</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="container">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show"><?php echo e(session('success')); ?></div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h5>Add New Course</h5>
                    </div>
                    <form action="<?php echo e(route('courses.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <!-- Course Name -->
                                    <div class="mb-3 row">
                                        <label class="col-sm-3 col-form-label">Course Name</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="text" name="name" placeholder="Course Name" required>
                                        </div>
                                    </div>

                                    <!-- Description (Quill Editor) -->
                                    <div class="mb-3 row">
                                        <label class="col-sm-3 col-form-label">Description</label>
                                        <div class="col-sm-9">
                                            <div class="email-wrapper">
                                                <div class="theme-form">
                                                    <div class="mb-3">
                                                        <label class="w-100">Content:</label>
                                                        <div id="editor8"></div>
                                                        <input type="hidden" name="description" id="description">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Duration -->
                                    <div class="mb-3 row">
                                        <label class="col-sm-3 col-form-label">Duration (Days)</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="number" name="duration" placeholder="Course Duration in Days" required>
                                        </div>
                                    </div>

                                    <!-- Total Price -->
                                    <div class="mb-3 row">
                                        <label class="col-sm-3 col-form-label">Total Price (Rs.)</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="number" name="total_price" placeholder="Total Price" required>
                                        </div>
                                    </div>

                                    <!-- First Payment -->
                                    <div class="mb-3 row">
                                        <label class="col-sm-3 col-form-label">First Payment (Rs.)</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="number" name="first_payment" placeholder="First Payment" required>
                                        </div>
                                    </div>

                                    <!-- Upload Image -->
                                    <div class="mb-3 row">
                                        <label class="col-sm-3 col-form-label">Course Image</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="file" name="image" accept="image/*">
                                        </div>
                                    </div>

                                    <!-- Location -->
                                    <div class="mb-3 row">
                                        <label class="col-sm-3 col-form-label">Location</label>
                                        <div class="col-sm-9">
                                            <input class="form-control" type="text" name="location" placeholder="Course Location (e.g., Colombo, Online)">
                                        </div>
                                    </div>

                                    <!-- Mode -->
                                    <div class="mb-3 row">
                                        <label class="col-sm-3 col-form-label">Mode</label>
                                        <div class="col-sm-9">
                                            <select name="mode" class="form-control" required>
                                                <option value="online">Online</option>
                                                <option value="offline">Offline</option>
                                                <option value="hybrid">Hybrid</option>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- Branch -->
                                    <div class="mb-3 row">
                                        <label class="col-sm-3 col-form-label">Branch</label>
                                        <div class="col-sm-9">
                                            <select name="branch_id" class="form-control">
                                                <option value="">-- Select Branch --</option>
                                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        
                        <div class="card-footer text-end">
                            <div class="col-sm-9 offset-sm-3">
                                <button class="btn btn-primary" type="submit" onclick="submitForm()">Submit</button>
                                <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-light">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- Include Quill JS -->
<script src="../assets/js/editors/quill.js"></script>

<script>
    // Initialize Quill editor
    var quill = new Quill('#editor8', {
        theme: 'snow',
        modules: {
            toolbar: [
                [{ 'size': ['small', false, 'large', 'huge'] }],
                ['bold', 'italic', 'underline', 'strike'],
                [{ 'script': 'sub'}, { 'script': 'super' }],
                ['blockquote', 'code-block'],
                [{ 'header': 1 }, { 'header': 2 }],
                [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                [{ 'indent': '-1'}, { 'indent': '+1' }],
                [{ 'direction': 'rtl' }],
                [{ 'color': [] }, { 'background': [] }],
                [{ 'align': [] }],
                ['link', 'image', 'video'],
                ['clean']
            ]
        }
    });

    // Set Quill content to hidden input on form submission
    function submitForm() {
        document.getElementById('description').value = quill.root.innerHTML;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/courses/create.blade.php ENDPATH**/ ?>