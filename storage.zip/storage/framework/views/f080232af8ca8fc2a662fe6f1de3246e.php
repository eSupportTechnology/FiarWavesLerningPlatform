

<?php $__env->startSection('title', 'YouTube Videos'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>YouTube Videos</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Media</li>
    <li class="breadcrumb-item active">YouTube Videos</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Error!</strong> Please check the form below.<br><br>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Create Form -->
    <div class="card mb-4">
        <div class="card-header">
            <h5>Add New YouTube Video</h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.youtube-videos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="title" class="form-label">Video Title</label>
                        <input type="text" name="title" id="title" class="form-control" placeholder="Enter video title" required>
                    </div>
                    <div class="col-md-6">
                        <label for="youtube_url" class="form-label">YouTube URL</label>
                        <input type="url" name="youtube_url" id="youtube_url" class="form-control" placeholder="https://www.youtube.com/watch?v=..." required>
                    </div>
                    <div class="col-12 text-end">
                        <button type="submit" class="btn btn-success">Add Video</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Video List -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>All YouTube Videos</h5>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover text-center">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Preview</th>
                            <th>URL</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($video->title); ?></td>
                                <td>
                                    <iframe width="200" height="113"
                                        src="https://www.youtube.com/embed/<?php echo e(\Illuminate\Support\Str::after($video->youtube_url, 'v=')); ?>"
                                        frameborder="0" allowfullscreen>
                                    </iframe>
                                </td>
                                <td>
                                    <a href="<?php echo e($video->youtube_url); ?>" target="_blank">
                                        <?php echo e($video->youtube_url); ?>

                                    </a>
                                </td>
                                <td class="d-flex justify-content-center gap-2">
                                    <a href="<?php echo e(route('admin.youtube-videos.edit', $video->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                    <form action="<?php echo e(route('admin.youtube-videos.destroy', $video->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this video?');">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5">No videos found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/youtube_videos/index.blade.php ENDPATH**/ ?>