

<?php $__env->startSection('title', 'VIP Packages'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>VIP Packages</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Packages</li>
    <li class="breadcrumb-item active">All</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>All VIP Packages</h5>
            <a href="<?php echo e(route('vip-packages.create')); ?>" class="btn btn-primary">+ Add New</a>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover text-center">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Price (Rs)</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td>
                                    <?php if($package->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $package->image)); ?>" width="70">
                                    <?php else: ?>
                                        <span class="text-muted">No image</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($package->title); ?></td>
                                <td><?php echo e(number_format($package->price)); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($package->status === 'active' ? 'success' : 'secondary'); ?>">
                                        <?php echo e(ucfirst($package->status)); ?>

                                    </span>
                                </td>
                                <td class="d-flex justify-content-center gap-2">
                                    <a href="<?php echo e(route('vip-packages.edit', $package->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                    <form action="<?php echo e(route('vip-packages.destroy', $package->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6">No VIP packages found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/vip_packages/index.blade.php ENDPATH**/ ?>