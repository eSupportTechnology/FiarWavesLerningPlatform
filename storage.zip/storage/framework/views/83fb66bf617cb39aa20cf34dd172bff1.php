

<?php $__env->startSection('title', 'Manage Blogs'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Manage Blogs</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Content</li>
    <li class="breadcrumb-item active">Blogs</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>All Blogs</h5>
            <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-primary">+ Add New Blog</a>
        </div>

        <div class="card-body table-responsive">
            <table class="table table-bordered text-center align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Media</th>
                        <th>Status</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e(Str::limit($blog->title, 50)); ?></td>
                            <td>
                                <?php if($blog->media_type === 'image' && $blog->media_path): ?>
                                    <img src="<?php echo e(asset('storage/' . $blog->media_path)); ?>" width="100" class="img-thumbnail">
                                <?php elseif($blog->media_type === 'video' && $blog->media_path): ?>
                                    <video width="150" controls>
                                        <source src="<?php echo e(asset('storage/' . $blog->media_path)); ?>" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php else: ?>
                                    <span class="text-muted">No Media</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($blog->status ? 'success' : 'secondary'); ?>">
                                    <?php echo e($blog->status ? 'Published' : 'Unpublished'); ?>

                                </span>
                            </td>
                            <td><?php echo e($blog->created_at->format('d M Y')); ?></td>
                            <td class="d-flex justify-content-center gap-2 flex-wrap">
                                <a href="<?php echo e(route('admin.blogs.edit', $blog->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                <form action="<?php echo e(route('admin.blogs.destroy', $blog->id)); ?>" method="POST" onsubmit="return confirm('Delete this blog?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6">No blogs found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="mt-3">
                <?php echo e($blogs->links()); ?> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/blogs/index.blade.php ENDPATH**/ ?>