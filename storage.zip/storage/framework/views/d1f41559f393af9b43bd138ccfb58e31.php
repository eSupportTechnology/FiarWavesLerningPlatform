

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h4 class="mb-3">Recordings for: <strong><?php echo e($booking->course->name); ?></strong></h4>

    <?php $__empty_1 = true; $__currentLoopData = $booking->course->recordings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-body">
                <h6 class="mb-1"><?php echo e($rec->week_name); ?></h6>
                <p class="mb-2 text-muted"><?php echo e($rec->description); ?></p>
                <a href="<?php echo e($rec->recording_url); ?>" target="_blank" class="btn btn-sm btn-outline-danger">
                    <i class="bi bi-camera-video"></i> Watch Recording
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-muted">No video recordings found.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('StudentDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/StudentDashboard/course/recordings.blade.php ENDPATH**/ ?>