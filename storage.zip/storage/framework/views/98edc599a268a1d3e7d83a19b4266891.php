

<?php $__env->startSection('title', 'Customer Management'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>All Customers</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Users</li>
    <li class="breadcrumb-item active">Customers</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>Customer List</h5>
            <!-- Optional: Add Customer -->
            
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover text-center">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($customer->stu_id); ?></td>
                                <td><?php echo e($customer->name); ?></td>
                                <td><?php echo e($customer->email); ?></td>
                                <td><?php echo e($customer->contact_number); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($customer->status ? 'success' : 'secondary'); ?>">
                                        <?php echo e($customer->status ? 'Active' : 'Inactive'); ?>

                                    </span>
                                </td>
                                <td class="d-flex flex-wrap justify-content-center gap-2">
                                    <form action="<?php echo e(route('admin.customers.toggleStatus', $customer->user_id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-<?php echo e($customer->status ? 'warning' : 'success'); ?>">
                                            <?php echo e($customer->status ? 'Deactivate' : 'Activate'); ?>

                                        </button>
                                    </form>

                                    <a href="<?php echo e(route('admin.customers.show', $customer->user_id)); ?>" class="btn btn-sm btn-info">
                                        View More
                                    </a>

                                    <form action="<?php echo e(route('admin.customers.destroy', $customer->user_id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this customer?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7">No customers found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="mt-3">
                    <?php echo e($customers->links()); ?>

                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/customers/index.blade.php ENDPATH**/ ?>