

<?php $__env->startSection('title', 'Add New Review'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Add New Review</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.reviews.index')); ?>">Reviews</a></li>
    <li class="breadcrumb-item active">Create</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Error!</strong> Please check the form below.<br><br>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5>New Review Form</h5>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('admin.reviews.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="course_id" class="form-label">Course</label>
                        <select name="course_id" class="form-control" required>
                            <option value="">Select Course</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->course_id); ?>"><?php echo e($course->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="student_name" class="form-label">Student Name</label>
                        <input type="text" name="student_name" class="form-control" required>
                    </div>

                    <div class="col-md-6">
                        <label for="rating" class="form-label">Rating</label>
                        <select name="rating" class="form-control" required>
                            <option value="">Select Rating</option>
                            <?php for($i = 5; $i >= 1; $i--): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?> Star<?php echo e($i > 1 ? 's' : ''); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" class="form-control" required>
                            <option value="approved">Approved</option>
                            <option value="pending">Pending</option>
                        </select>
                    </div>

                    <div class="col-12">
                        <label for="comment" class="form-label">Comment</label>
                        <textarea name="comment" class="form-control" rows="4" required></textarea>
                    </div>

                    <div class="col-12">
                        <label for="image" class="form-label">Upload Image (optional)</label>
                        <input type="file" name="image" class="form-control">
                    </div>

                    <div class="col-12 text-end">
                        <a href="<?php echo e(route('admin.reviews.index')); ?>" class="btn btn-secondary">Cancel</a>
                        <button type="submit" class="btn btn-success">Submit Review</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/reviews/create.blade.php ENDPATH**/ ?>