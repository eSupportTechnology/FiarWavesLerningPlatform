

<?php $__env->startSection('title', 'Booking Details'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Booking Details</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Bookings</li>
    <li class="breadcrumb-item active">View</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row g-4">
        <!-- Left Column: Customer Details -->
        <div class="col-lg-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Customer Information</h5>
                </div>
                <div class="card-body">
                    <p><strong>Name:</strong> <?php echo e($booking->customer->name); ?></p>
                    <p><strong>Email:</strong> <?php echo e($booking->customer->email); ?></p>
                    <p><strong>Contact Number:</strong> <?php echo e($booking->customer->contact_number); ?></p>
                    <p><strong>Address:</strong> <?php echo e($booking->customer->address ?? 'N/A'); ?></p>
                    <p><strong>Status:</strong> 
                        <span class="badge bg-success"><?php echo e($booking->customer->status); ?></span>
                    </p>
                    <p><strong>Registered On:</strong> <?php echo e($booking->customer->created_at->format('d M Y')); ?></p>
                </div>
            </div>
        </div>

        <!-- Right Column: Booking + Course Info -->
        <div class="col-lg-6">
            <div class="card shadow-sm">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0">Booking & Course Info</h5>
                </div>
                <div class="card-body">
                    <p><strong>Course:</strong> <?php echo e($booking->course->name ?? 'N/A'); ?></p>
                    <p><strong>Duration:</strong> <?php echo e($booking->course->duration); ?> Days</p>
                    <p><strong>Total Price:</strong> Rs. <?php echo e(number_format($booking->course->total_price, 2)); ?></p>
                    <p><strong>First Payment:</strong> Rs. <?php echo e(number_format($booking->course->first_payment, 2)); ?></p>

                    <hr>
                    <p><strong>Payment Method:</strong> <?php echo e($booking->payment_method); ?></p>
                    <p><strong>Payment Status:</strong> 
                        <?php if($booking->payment_status === 'half'): ?>
                            <span class="text-warning">First Payment</span>
                        <?php else: ?>
                            <span class="text-success">Full Payment</span>
                        <?php endif; ?>
                    </p>
                    <p><strong>Booking Status:</strong> 
                        <span class="badge bg-<?php echo e($booking->status === 'Pending' ? 'warning' : 'success'); ?>">
                            <?php echo e($booking->status); ?>

                        </span>
                    </p>
                    
                    <?php if($booking->payment_method === 'Bank Transfer'): ?>
                        <hr>
                        <h6>Bank Transfer Details</h6>
                        <p><strong>Bank:</strong> <?php echo e($booking->bank_name ?? '-'); ?></p>
                        <p><strong>Branch:</strong> <?php echo e($booking->bank_branch ?? '-'); ?></p>
                        <p><strong>Transfer Date:</strong> <?php echo e($booking->transfer_date ?? '-'); ?></p>
                        <?php if($booking->receipt_path): ?>
                            <p><strong>Receipt:</strong><br>
                                <a href="<?php echo e(asset('storage/' . $booking->receipt_path)); ?>" target="_blank" class="btn btn-sm btn-info mt-1">
                                    View Receipt
                                </a>
                            </p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Optional Admin Notes -->
    <?php if($booking->admin_notes): ?>
    <div class="card mt-4 shadow-sm">
        <div class="card-header bg-light">
            <h5 class="mb-0">Admin Notes</h5>
        </div>
        <div class="card-body">
            <p><?php echo e($booking->admin_notes); ?></p>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/bookings/show.blade.php ENDPATH**/ ?>