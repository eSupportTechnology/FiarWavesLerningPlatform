

<?php $__env->startSection('title', 'Course Reviews'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Course Reviews</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Feedback</li>
    <li class="breadcrumb-item active">Reviews</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>All Reviews</h5>
            <a href="<?php echo e(route('admin.reviews.create')); ?>" class="btn btn-primary">+ Add Review</a>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover text-center">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Course</th>
                            <th>Student</th>
                            <th>Rating</th>
                            <th>Comment</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($review->course->name ?? 'N/A'); ?></td>
                                <td><?php echo e($review->student_name); ?></td>
                                <td>
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fa fa-star<?php echo e($i <= $review->rating ? '' : '-o'); ?>"></i>
                                    <?php endfor; ?>
                                </td>
                                <td><?php echo e(\Illuminate\Support\Str::limit($review->comment, 50)); ?></td>
                                <td>
                                    <?php if($review->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $review->image)); ?>" width="60" class="rounded">
                                    <?php else: ?>
                                        <span class="text-muted">No image</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e($review->status === 'approved' ? 'success' : 'warning'); ?>">
                                        <?php echo e(ucfirst($review->status)); ?>

                                    </span>
                                </td>
                                <td class="d-flex flex-wrap justify-content-center gap-2">
                                    <form action="<?php echo e(route('admin.reviews.toggleStatus', $review->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-<?php echo e($review->status === 'approved' ? 'warning' : 'success'); ?>">
                                            <?php echo e($review->status === 'approved' ? 'Deactivate' : 'Approve'); ?>

                                        </button>
                                    </form>

                                    <a href="<?php echo e(route('admin.reviews.edit', $review->id)); ?>" class="btn btn-sm btn-info">Edit</a>

                                    <form action="<?php echo e(route('admin.reviews.destroy', $review->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this review?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8">No reviews found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="mt-3">
                    <?php echo e($reviews->links()); ?> <!-- Pagination if you're using paginate() -->
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/reviews/index.blade.php ENDPATH**/ ?>