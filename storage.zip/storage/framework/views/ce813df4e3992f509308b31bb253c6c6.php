

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    <!-- Back Button -->
    <div class="mb-3">
        <a href="<?php echo e(route('student.bookings')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left-circle"></i> Back to My Courses
        </a>
    </div>

    <!-- Course Card -->
    <div class="card shadow border-0">
        <div class="row g-0">
            <div class="col-md-5">
                <?php if($booking->course->image): ?>
                    <img src="<?php echo e(asset($booking->course->image)); ?>" class="img-fluid rounded-start w-100 h-100 object-fit-cover" alt="<?php echo e($booking->course->name); ?>">
                <?php else: ?>
                    <div class="bg-light d-flex align-items-center justify-content-center h-100" style="height: 100%;">
                        <span class="text-muted">No Image</span>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-7">
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($booking->course->name); ?></h3>
                    <p class="card-text"><strong>Duration:</strong> <?php echo e($booking->course->duration); ?> days</p>
                    <p class="card-text"><strong>Mode:</strong> <?php echo e(ucfirst($booking->course->mode)); ?></p>
                    <p class="card-text"><strong>Location:</strong> <?php echo e($booking->course->location); ?></p>
                    <p class="card-text"><strong>Total Price:</strong> Rs. <?php echo e(number_format($booking->course->total_price, 2)); ?></p>
                    <p class="card-text"><strong>Paid:</strong> <?php echo e(ucfirst($booking->payment_status)); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('StudentDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/StudentDashboard/course/view.blade.php ENDPATH**/ ?>