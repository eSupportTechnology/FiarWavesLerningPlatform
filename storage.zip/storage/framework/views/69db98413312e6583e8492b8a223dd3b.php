
<?php $__env->startSection('title', 'View Course Details'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>View Course Details</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Course Management</li>
    <li class="breadcrumb-item active">Course Details</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5>Course Details</h5>
                    <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-primary">Back to Courses</a>
                </div>
                <div class="card-body">

                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Course Image:</strong><br>
                            <?php if($course->image): ?>
                                <img src="<?php echo e(asset($course->image)); ?>" alt="Course Image" width="200" class="img-thumbnail mt-2">
                            <?php else: ?>
                                <p>No Image Available</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Course Name:</strong>
                            <p><?php echo e($course->name); ?></p>
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <strong>Description:</strong>
                            <div class="border p-3 rounded bg-light text-black">
                                <?php echo $course->description ?? '<em>No description provided.</em>'; ?>

                            </div>
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Duration (Days):</strong>
                            <p><?php echo e($course->duration); ?></p>
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Total Price (Rs.):</strong>
                            <p><?php echo e(number_format($course->total_price, 2)); ?></p>
                        </div>
                        
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>First Payment (Rs.):</strong>
                            <p><?php echo e(number_format($course->first_payment, 2)); ?></p>
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Location:</strong>
                            <p><?php echo e($course->location ?? 'N/A'); ?></p>
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Mode:</strong>
                            <p class="text-capitalize"><?php echo e($course->mode); ?></p>
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Branch:</strong>
                            <p><?php echo e($course->branch->name ?? 'N/A'); ?></p>
                        </div>
                    </div>


                    

                   

                </div> <!-- /card-body -->
            </div> <!-- /card -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/courses/show.blade.php ENDPATH**/ ?>