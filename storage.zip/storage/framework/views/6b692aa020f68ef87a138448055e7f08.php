

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h4 class="mb-3">Files for: <strong><?php echo e($booking->course->name); ?></strong></h4>

    <?php $__empty_1 = true; $__currentLoopData = $booking->course->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h6><?php echo e($file->file_name); ?></h6>
                    <small class="text-muted"><?php echo e($file->file_type); ?></small>
                </div>
                <a href="<?php echo e(asset($file->file_path)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-download"></i> Download
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-muted">No files available for this course.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('StudentDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/StudentDashboard/course/files.blade.php ENDPATH**/ ?>