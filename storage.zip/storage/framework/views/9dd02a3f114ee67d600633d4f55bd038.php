
<?php $__env->startSection('title', 'Edit Branch'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <div class="card">
        <div class="card-header"><h5>Edit Branch</h5></div>
        <div class="card-body">
            <form action="<?php echo e(route('branches.update', $branch->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                    <label class="form-label">Branch Name</label>
                    <input type="text" name="name" value="<?php echo e($branch->name); ?>" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Address</label>
                    <input type="text" name="address" value="<?php echo e($branch->address); ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" value="<?php echo e($branch->phone); ?>" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?php echo e(route('branches.index')); ?>" class="btn btn-secondary">Back</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/branches/edit.blade.php ENDPATH**/ ?>