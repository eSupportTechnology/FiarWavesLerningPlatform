
<?php $__env->startSection('title', 'Edit Blog'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/quill.snow.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    #editor8 {
        height: 300px;
        background-color: white;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Edit Blog</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.blogs.index')); ?>">Blogs</a></li>
    <li class="breadcrumb-item active">Edit</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h5>Edit Blog</h5>
                </div>

                <form action="<?php echo e(route('admin.blogs.update', $blog->id)); ?>" method="POST" enctype="multipart/form-data" onsubmit="return submitForm()">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <!-- Title -->
                                <div class="col-md-12 mb-3">
                                    <label class="form-label">Title</label>
                                    <input class="form-control" type="text" name="title" value="<?php echo e(old('title', $blog->title)); ?>" required>
                                </div>

                                <!-- Media Type -->
                                <div class="col-md-12 mb-3">
                                    <label class="form-label">Media Type</label>
                                    <select name="media_type" id="media_type" class="form-control" required>
                                        <option value="image" <?php echo e($blog->media_type == 'image' ? 'selected' : ''); ?>>Image</option>
                                        <option value="video" <?php echo e($blog->media_type == 'video' ? 'selected' : ''); ?>>Video</option>
                                    </select>
                                </div>

                                <!-- Content (Quill Editor) -->
                                <div class="col-md-12 mb-3">
                                    <label class="form-label">Content</label>
                                    <div id="editor8"></div>
<input type="hidden" name="content" id="content" value="<?php echo e(old('content', $blog->content)); ?>">

                                </div>

                                <!-- Media Upload -->
                                <div class="col-md-12 mb-3" id="media_upload">
                                    <label class="form-label">Upload Media (Image/Video)</label>
                                    <input type="file" name="media_file" class="form-control">
                                    <small class="text-muted">Leave blank to keep existing. Max 20MB.</small>
                                    <?php if($blog->media_path): ?>
                                        <div class="mt-2">
                                            <strong>Current:</strong><br>
                                            <?php if($blog->media_type == 'image'): ?>
                                                <img src="<?php echo e(asset('storage/' . $blog->media_path)); ?>" width="200" class="rounded">
                                            <?php else: ?>
                                                <video width="300" controls>
                                                    <source src="<?php echo e(asset('storage/' . $blog->media_path)); ?>">
                                                    Your browser does not support the video tag.
                                                </video>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Status -->
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-control" required>
                                        <option value="1" <?php echo e($blog->status == 1 ? 'selected' : ''); ?>>Published</option>
                                        <option value="0" <?php echo e($blog->status == 0 ? 'selected' : ''); ?>>Unpublished</option>
                                    </select>
                                </div>

                                <!-- Submit -->
                                <div class="col-12 text-end mb-3">
                                    <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn btn-secondary">Cancel</a>
                                    <button type="submit" class="btn btn-primary">Update Blog</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/editors/quill.js')); ?>"></script>

<script>
        var quill = new Quill('#editor8', {
        theme: 'snow',
        modules: {
            toolbar: [
                [{ 'size': ['small', false, 'large', 'huge'] }],
                ['bold', 'italic', 'underline', 'strike'],
                [{ 'script': 'sub'}, { 'script': 'super' }],
                ['blockquote', 'code-block'],
                [{ 'header': 1 }, { 'header': 2 }],
                [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                [{ 'indent': '-1'}, { 'indent': '+1' }],
                [{ 'direction': 'rtl' }],
                [{ 'color': [] }, { 'background': [] }],
                [{ 'align': [] }],
                ['link', 'image', 'video'],
                ['clean']
            ]
        }
    });

    // Set initial content into Quill editor from hidden input
    quill.root.innerHTML = document.getElementById('content').value;

    // Sync content to hidden input before form submit
    function submitForm() {
        document.getElementById('content').value = quill.root.innerHTML;
        return true;
    }

    // Optional: change label when media_type is changed
    document.getElementById('media_type').addEventListener('change', function () {
        const label = document.querySelector('#media_upload label');
        label.textContent = this.value === 'video' ? 'Upload Video' : 'Upload Image';
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/blogs/edit.blade.php ENDPATH**/ ?>