

<?php $__env->startSection('title', 'Manage Banners'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Manage Banners</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Settings</li>
    <li class="breadcrumb-item active">Banners</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>There were some problems with your input:</strong>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Banner Form (Create / Update) -->
    <div class="card mb-4">
        <div class="card-header">
            <h5><?php echo e(isset($bannerToEdit) ? 'Edit Banner' : 'Add New Banner'); ?></h5>
        </div>
        <div class="card-body">
            <form 
                action="<?php echo e(isset($bannerToEdit) ? route('admin.banners.update', $bannerToEdit->id) : route('admin.banners.store')); ?>" 
                method="POST" 
                enctype="multipart/form-data"
            >
                <?php echo csrf_field(); ?>
                <?php if(isset($bannerToEdit)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Banner Image <small>(Max: 10MB)</small></label>
                        <input type="file" name="image" class="form-control" <?php echo e(isset($bannerToEdit) ? '' : 'required'); ?>>
                        
                        <?php if(isset($bannerToEdit) && $bannerToEdit->image): ?>
                            <div class="mt-2">
                                <img src="<?php echo e(asset('storage/' . $bannerToEdit->image)); ?>" width="100" class="img-thumbnail">
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Redirect Link (optional)</label>
                        <input 
                            type="url" 
                            name="link" 
                            class="form-control" 
                            value="<?php echo e(old('link', $bannerToEdit->link ?? '')); ?>"
                        >
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control" required>
                            <option value="1" <?php echo e((old('status', $bannerToEdit->status ?? '') == 1) ? 'selected' : ''); ?>>Active</option>
                            <option value="0" <?php echo e((old('status', $bannerToEdit->status ?? '') == 0) ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>

                    <div class="col-12 text-end">
                        <?php if(isset($bannerToEdit)): ?>
                            <a href="<?php echo e(route('admin.banners.index')); ?>" class="btn btn-secondary">Cancel</a>
                            <button type="submit" class="btn btn-warning">Update</button>
                        <?php else: ?>
                            <button type="submit" class="btn btn-success">Create Banner</button>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Banner List Table -->
    <div class="card">
        <div class="card-header">
            <h5>All Banners</h5>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered text-center">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Preview</th>
                        <th>Link</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/' . $banner->image)); ?>" width="150" class="img-thumbnail">
                            </td>
                            <td>
                                <?php if($banner->link): ?>
                                    <a href="<?php echo e($banner->link); ?>" target="_blank"><?php echo e($banner->link); ?></a>
                                <?php else: ?>
                                    <span class="text-muted">No link</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($banner->status ? 'success' : 'secondary'); ?>">
                                    <?php echo e($banner->status ? 'Active' : 'Inactive'); ?>

                                </span>
                            </td>
                            <td class="d-flex justify-content-center gap-2 flex-wrap">
                                <a href="#" 
                                    class="btn btn-sm btn-info" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#editModal<?php echo e($banner->id); ?>">
                                    Edit
                                </a>

                                <form action="<?php echo e(route('admin.banners.destroy', $banner->id)); ?>" method="POST" onsubmit="return confirm('Delete this banner?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5">No banners added yet.</td></tr>
                    <?php endif; ?>



                    
                </tbody>

                
            </table>

            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Edit Modal -->
<div class="modal fade" id="editModal<?php echo e($banner->id); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($banner->id); ?>" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <form action="<?php echo e(route('admin.banners.update', $banner->id)); ?>" method="POST" enctype="multipart/form-data" class="modal-content">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="modal-header">
            <h5 class="modal-title" id="editModalLabel<?php echo e($banner->id); ?>">Edit Banner</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body row g-3">
            <div class="col-md-6">
                <label class="form-label">Banner Image</label>
                <input type="file" name="image" class="form-control">
                <?php if($banner->image): ?>
                    <div class="mt-2">
                        <img src="<?php echo e(asset('storage/' . $banner->image)); ?>" width="100" class="img-thumbnail">
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-md-6">
                <label class="form-label">Redirect Link</label>
                <input type="url" name="link" class="form-control" value="<?php echo e($banner->link); ?>">
            </div>

            <div class="col-md-6">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="1" <?php echo e($banner->status ? 'selected' : ''); ?>>Active</option>
                    <option value="0" <?php echo e(!$banner->status ? 'selected' : ''); ?>>Inactive</option>
                </select>
            </div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-warning">Update</button>
        </div>
    </form>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="mt-3">
                <?php echo e($banners->links()); ?> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/banners/index.blade.php ENDPATH**/ ?>