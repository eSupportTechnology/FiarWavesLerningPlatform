

<?php $__env->startSection('title', 'Pending Booking Requests'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Pending Bookings</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Bookings</li>
    <li class="breadcrumb-item active">Pending</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5>Pending Booking Requests</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Customer</th>
                            <th>Course</th>
                            <th>Contact Number</th>
                            <th>Payment</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($booking->customer->name ?? 'N/A'); ?></td>
                                <td><?php echo e($booking->course->name ?? 'N/A'); ?></td>
                                <td><?php echo e($booking->customer->contact_number ?? 'N/A'); ?></td>
                                <td><?php echo e($booking->payment_method); ?><br>
                                    <?php if($booking->payment_status === 'half'): ?>
                                        <small class="text-warning">First Payment</small>
                                    <?php else: ?>
                                        <small class="text-success">Full Payment</small>
                                    <?php endif; ?>
                                </td>
                                <td><span class="badge bg-warning"><?php echo e($booking->status); ?></span></td>
                                <td class="d-flex gap-2">
                                    <!-- Approve -->
                                    <form action="<?php echo e(route('admin.bookings.approve', $booking->id)); ?>" method="POST" onsubmit="return confirm('Approve this booking?');">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-success">Approve</button>
                                    </form>

                                    <!-- View More -->
                                    <a href="<?php echo e(route('admin.bookings.show', $booking->id)); ?>" class="btn btn-sm btn-info">View</a>

                                    <!-- Delete -->
                                    <form action="<?php echo e(route('admin.bookings.destroy', $booking->id)); ?>" method="POST" onsubmit="return confirm('Are you sure to delete this booking?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">No pending bookings found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/bookings/pending.blade.php ENDPATH**/ ?>